// Small interaction: make external links open normally and add a subtle page-load effect.
document.documentElement.classList.add("loaded");
